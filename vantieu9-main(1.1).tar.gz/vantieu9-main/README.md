# Vận tiêu Long Môn Trấn 9
 
## Giới Thiệu
Đây là bộ source code vận tiêu Long Môn Trấn từ JXLinux 9

Link download phiên bản mới nhất: [main.tar.gz](https://github.com/vinh-ttn/vantieu9/archive/refs/heads/main.tar.gz) 

(đã được chỉnh sửa để chạy trên bản 8, có thể bao gồm cả bản 6 - dùng 7z để giải nén)

Phiên bản hiện tại: **1.1**

Nếu có thắc mắc, ý kiến đóng góp, báo lỗi hay các vấn đề liên quan về bộ source có thể xem [tại đây](https://github.com/vinh-ttn/vantieu9/issues)

## Cài đặt

Sau khi download file zip về:

- chép đè **gateway** trong zip file lên **gateway** trên server
- chép đè **server1** lên **server1** trên server
- khởi động server game lại và vào chơi game.

Hoặc nếu dùng 1ClickVMFull có thể cài đặt nhanh bằng địa chỉ **vinh-ttn/vantieu9**

## Thay đổi 

|                          | Ngày       | Thay đổi                                                                                                       |
| ------------------------ | ---------- | ---------------------------------------------------------------------------------------------------------------|
| **1.0**                  | 14/07/2024 | Phiên bản gốc chưa chỉnh sửa gì                                                                                |
| **1.1**                  | 21/07/2024 | Sửa lỗi tiêu không thể đi qua các thành. Thêm chức năng khóa THP TDP TTTAP khi đang vận tiêu như yêu cầu event.|



## Thông tin thêm
Nội dung [bài viết gốc](https://www.facebook.com/groups/volamquan/posts/1403274900381698):

> [Kiều Thắng](https://www.facebook.com/groups/800085930700601/user/100002850117432) - #share  14/07/2024 
>  mình được ông anh cho bộ vận tiêu long môn của 9.0 để nghịch, mà hàng 9.0 đưa xuống 8.0 nó còn thiếu sót nhiều nên chưa
> fix hết được hoàn chỉnh, mới làm cho tiêu 1* chạy trong lâm an thôi,
> còn phần tiêu qua map chưa làm được, mong các cao nhân hợp tác fix để
> cho ae hội quán có thêm 1 tính năng để ae chơi off cho đỡ buồn chán
> 
> Chúc anh em cuối tuần vui vẻ ![😃](https://static.xx.fbcdn.net/images/emoji.php/v9/t51/1/16/1f603.png)
> 
> 
> Link gốc chưa chỉnh sửa gì:
> [https://drive.google.com/.../14ESqmk0bbbDia4Dt2iJ.../view...](https://drive.google.com/file/d/14ESqmk0bbbDia4Dt2iJvd0xQL3s9uMag/view?usp=sharing&fbclid=IwZXh0bgNhZW0CMTAAAR1ChT0TsPIF8NzfubOiJxJs_neZNTCoC0OA-_h7Y3JjI7XuQjsscHrbFfQ_aem_ie5cceuFfKWWDzlyIoV0wA)
![](https://lh7-us.googleusercontent.com/docsz/AD_4nXdy49bB43m45QRv01xvtQf-wXIkzH_KEBz4n8PkfGq2n78-354wc5-9oP4_K_0wttuFPfeYIyQKNdenfuDGI8ev9thfjen1fXLGyAYitRw414LNsujWI3XHJS7BomZwmkbOAYM-iMsNSxRBGrkpmSJNLjS1?key=69JrhYHE20yyd5Bd1uKvkw)
![](https://lh7-us.googleusercontent.com/docsz/AD_4nXdNQjves8csWFXWOf10pgOH1I1jAM29g2RjqgJzbzhW8kiZ0pXsKTLK05HncR5A_4ZY6vrVoXDoI4NasJta93DSmUqBSOXke_FtnWk-KacuZIkbBc6s4jOJCeOKE28ZljICHLLFxl6WJkbGmvfPh4wmA6vF?key=69JrhYHE20yyd5Bd1uKvkw)
![](https://lh7-us.googleusercontent.com/docsz/AD_4nXf1O0ivUQ8OkdJpAk9VgLAxVnmzuhuj_yvPVmRK026KuF2gqTFH6RrsQBnfhTv0fZ1X5qnDHoMG3waI9Af7oVG2NdrMSOCOOuA94dEUgksN-3U5_rHZ0umNo_P75cLgD8db3jG8Vcrbp6OIM45bBulrB14j?key=69JrhYHE20yyd5Bd1uKvkw)
![](https://lh7-us.googleusercontent.com/docsz/AD_4nXdsMuRsX3eo0HzEZVQ8nG23opawX5eS4lu29W4j2HatXAHPnZSFx0NCakzg9TMMLn_npl_53nl3b3PbsNYg9P1j4jnS4JOBnVkVVc6nmS0iLz7KwZGYS51MG7plWqTzlmiKXxS1zb9SCpgiZ0B4SuTvp6W8?key=69JrhYHE20yyd5Bd1uKvkw)
![](https://lh7-us.googleusercontent.com/docsz/AD_4nXcoPMJ1qMdQrMNKkDXaS80kiOmyO8BBNPW6CQaO4HgItnekzXJXE-Y2HHKV0E8ZaAhPKqL4oPtgfXSCf-JCaAQa3pMQD4Q-uAaCfq_gVC4iH6cfuPsLGi1ftkKspbN6hYyW1RH9G1I_b5LLbG_Wg04eAa4u?key=69JrhYHE20yyd5Bd1uKvkw)
