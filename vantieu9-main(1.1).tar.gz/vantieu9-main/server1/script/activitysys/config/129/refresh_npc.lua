-- 2013��ʮ���» --ˢNPC
Include("\\script\\lib\\objbuffer_head.lua")
Include("\\script\\missions\\basemission\\lib.lua")
Include("\\script\\activitysys\\config\\129\\variables.lua")


function RefreshLMBJCar(ParamHandle)

end
