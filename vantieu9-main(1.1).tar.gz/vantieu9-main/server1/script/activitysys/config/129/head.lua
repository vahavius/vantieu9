Include("\\script\\activitysys\\activity.lua")
pActivity = ActivityClass:new()
pActivity.nId = 129
pActivity.szName = "H� th�ng Long M�n Ti�u C�c"
pActivity.nStartDate = nil
pActivity.nEndDate = nil
pActivity.szDescription = "H� th�ng Long M�n Ti�u C�c"
pActivity.nGroupId = nil
pActivity.nVersion = nil
